// flex.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "lex.yy.c"
#include <locale.h>
#include <string>


void _tmain(int argc, _TCHAR* argv[])
{
	setlocale(LC_ALL, "russian");
	freopen("output.txt", "w", stdout);
	yyin = fopen("in.rb", "r");
	yylex();
}

